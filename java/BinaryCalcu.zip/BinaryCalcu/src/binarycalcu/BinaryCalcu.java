package binarycalcu;
import java.util.Scanner;
/**
 *
 * @author Aco
 */
public class BinaryCalcu {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String bin1, bin2, total, total1;
                int sum,dec1, dec2 ,x = 1, y = 0, operation, rem;
                
                do {
                    try {   
                System.out.println("[1]ADDITION [2]MULTIPLICATION [3]SUBTRACTION [4]DIVISION");
                System.out.printf("Enter Binary[1]: ");
                bin1 = input.next();
                System.out.printf("Enter Binary[2]: ");
                bin2 = input.next();
                dec1 = Integer.parseInt(bin1, 2);
                dec2 = Integer.parseInt(bin2, 2); 
                if (dec1 < 1 || dec2 < 1){
                System.out.println("Invalid Input");
                }else { 
                System.out.printf("Enter [#] of Operation: ");
                operation = input.nextInt();
                switch (operation){
                    case 1: sum = dec1 + dec2;
                            total = Integer.toBinaryString(sum);
                            System.out.println("Total is: " + total);
                            break;
                    case 2: sum = dec1 * dec2;
                            total = Integer.toBinaryString(sum);
                            System.out.println("Total is: " + total);
                            break;
                    case 3: sum = dec1 - dec2;
                            total = Integer.toBinaryString(sum);
                            System.out.println("Total is: " + total);
                            break;
                    case 4: 
                            sum = dec1 / dec2;
                            total = Integer.toBinaryString(sum);
                            rem = dec1 % dec2;
                            total1 = Integer.toBinaryString(rem);
                            if (dec1 % dec2 != 0 ){
                            System.out.println("Total is: " + total);
                            System.out.println("Remainder: " + total1);
                            }else{
                             System.out.println("Total is: " + total);
                            }

                            break;
                    default: 
                            System.out.println("Invalid Input");
                            break;
                            }
                 }
                }catch(Exception e){
        System.out.println("Invalid Input");
    }
                }while(x >= y);}
}
