/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package total_average_calcu;
import java.util.Scanner;
/**
 *
 * @author Aco
 */
public class Total_average_calcu {

    public static void main(String[] args) {
         Scanner console = new Scanner(System.in);
        float grades, average, sum=0;
        int subj=0,subj1 = 1;
        System.out.printf(" Enter how many subjects: ");
        subj = console.nextInt();
       do {
         System.out.printf(" Enter Grades [%d]: ", subj1);
         grades = console.nextInt();
         sum = grades + sum;
         subj1++;
       }while(subj1 <= subj);
        average = sum / subj;
        System.out.printf(" Total Average: %.1f" , average);
    }
    
}
